"""
AWS processing module
"""

def L0toL1():
	pass

	
def L1toL2():
	pass


def L1toL1A():
	pass


def L2toL3():
	pass
	

def toBUFR():
	pass
	
