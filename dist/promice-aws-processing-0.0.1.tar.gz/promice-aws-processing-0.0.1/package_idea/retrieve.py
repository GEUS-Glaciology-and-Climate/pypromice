"""
Data retrieval functions. Could be for retrieving raw station observations and other PROMICE/Dataverse datasets
"""


def getAWS(station_name):
	pass


def getDataset(data_name):
	pass


def checkDataverse():
	pass
